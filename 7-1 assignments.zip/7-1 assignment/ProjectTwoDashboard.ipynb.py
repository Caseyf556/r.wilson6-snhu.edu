from dash import Dash, dcc, html, dash_table
import dash_leaflet as dl
import plotly.express as px
from dash.dependencies import Input, Output, State
import base64
import pandas as pd
from crud_module import AnimalShelter

###########################
# Data Manipulation / Model
###########################

username = "aacuser"
password = "strongpassword"
connection_string = "mongodb://aacuser:strongpassword@nv-desktop-services.apporto.com:32768/?directConnection=true&appName=mongosh+1.8.0"

# Connect to database via CRUD Module
db = AnimalShelter(connection_string)

# Read data from MongoDB
df = pd.DataFrame.from_records(db.read({}))

# Drop the '_id' column
df.drop(columns=['_id'], inplace=True)

#########################
# Dashboard Layout / View
#########################
app = Dash(__name__)

# Add in Grazioso Salvare’s logo
image_filename = 'Grazioso Salvare Logo.png'  # replace with your own image
encoded_image = base64.b64encode(open(image_filename, 'rb').read())

app.layout = html.Div([
    html.Center(html.B(html.H1('CS-340 Dashboard'))),
    html.A(
        html.Img(src='data:image/png;base64,{}'.format(encoded_image.decode()), style={'height':'10%', 'width':'10%'}),
        href='https://www.snhu.edu', target='_blank'
    ),
    html.H2("Developed by Casey Farmer"),
    html.Hr(),
    html.Div([
        dcc.RadioItems(
            id='filter-type',
            options=[
                {'label': 'Water Rescue', 'value': 'Water Rescue'},
                {'label': 'Mountain/Wilderness Rescue', 'value': 'Mountain/Wilderness Rescue'},
                {'label': 'Disaster/Individual Tracking', 'value': 'Disaster/Individual Tracking'},
                {'label': 'Reset', 'value': 'Reset'}
            ],
            value='Reset',
            labelStyle={'display': 'inline-block'}
        )
    ]),
    html.Hr(),
    dash_table.DataTable(
        id='datatable-id',
        columns=[{"name": i, "id": i, "deletable": False, "selectable": True} for i in df.columns],
        data=df.to_dict('records'),
        style_table={'overflowX': 'scroll'},
        style_cell={'textAlign': 'left'},
        page_size=10,  # limits the number of rows per page
        sort_action='native',
        filter_action='native'
    ),
    html.Br(),
    html.Hr(),
    html.Div(className='row',
         style={'display': 'flex'},
             children=[
        html.Div(
            id='graph-id',
            className='col s12 m6',
        ),
        html.Div(
            id='map-id',
            className='col s12 m6',
        )
    ])
])

#############################################
# Interaction Between Components / Controller
#############################################

@app.callback(
    Output('datatable-id', 'data'),
    [Input('filter-type', 'value')]
)
def update_dashboard(filter_type):
    query = {}
    if filter_type == 'Water Rescue':
        query = {'breed': {'$in': ['Labrador Retriever Mix', 'Chesapeake Bay Retriever', 'Newfoundland']}}
    elif filter_type == 'Mountain/Wilderness Rescue':
        query = {'breed': {'$in': ['German Shepherd', 'Alaskan Malamute', 'Old English Sheepdog', 'Siberian Husky', 'Rottweiler']}}
    elif filter_type == 'Disaster/Individual Tracking':
        query = {'breed': {'$in': ['Doberman Pinscher', 'German Shepherd', 'Golden Retriever', 'Bloodhound', 'Rottweiler']}}
    else:
        query = {}

    df = pd.DataFrame.from_records(db.read(query))
    df.drop(columns=['_id'], inplace=True)
    return df.to_dict('records')

@app.callback(
    Output('graph-id', "children"),
    [Input('datatable-id', "derived_virtual_data")]
)
def update_graphs(viewData):
    if viewData is None:
        return html.Div()

    dff = pd.DataFrame.from_dict(viewData)
    fig = px.pie(dff, names='breed', title='Breed Distribution')
    return dcc.Graph(figure=fig)

@app.callback(
    Output('datatable-id', 'style_data_conditional'),
    [Input('datatable-id', 'selected_columns')]
)
def update_styles(selected_columns):
    if selected_columns is None:
        return []
    return [{
        'if': { 'column_id': i },
        'background_color': '#D2F3FF'
    } for i in selected_columns]

@app.callback(
    Output('map-id', "children"),
    [Input('datatable-id', "derived_virtual_data"),
     Input('datatable-id', "derived_virtual_selected_rows")]
)
def update_map(viewData, index):
    if viewData is None or not viewData:
        return []

    dff = pd.DataFrame.from_dict(viewData)
    if not index:
        row = 0
    else:
        row = index[0]

    try:
        lat = float(dff.iloc[row, dff.columns.get_loc('location_lat')])
        long = float(dff.iloc[row, dff.columns.get_loc('location_long')])
    except ValueError:
        return []

    return [
        dl.Map(style={'width': '1000px', 'height': '500px'}, center=[30.75, -97.48], zoom=10, children=[
            dl.TileLayer(id="base-layer-id"),
            dl.Marker(position=[lat, long], children=[
                dl.Tooltip(dff.iloc[row, dff.columns.get_loc('breed')]),
                dl.Popup([
                    html.H1("Animal Name"),
                    html.P(dff.iloc[row, dff.columns.get_loc('name')])
                ])
            ])
        ])
    ]

# Add a link to open the dashboard in a new tab
app.layout.children.append(html.A('Open Dashboard in New Tab', href='/_dash-update-component', target='_blank'))

if __name__ == '__main__':
    app.run_servr.Cursor object at 0x7f53744a0670>
Read query results: <pymongo.cursor.Cursor object at 0x7f53744a0550>
Read query results: <pymongo.cursor.Cursor object at 0x7f53744a0a90>